def create_study_plan(goal):
    return {
        "goal": goal,
        "plan": [
            "Day 1: Introduction",
            "Day 2: Basic Concepts",
            "Day 3: Practice Questions",
            "Day 4: Quiz",
            "Day 5: Revision"
        ]
    }