def generate_quiz(topic):
    return {
        "topic": topic,
        "questions": [
            {
                "question": f"What is {topic}?",
                "options": [
                    "Option A",
                    "Option B",
                    "Option C",
                    "Option D"
                ],
                "answer": "Option A"
            }
        ]
    }