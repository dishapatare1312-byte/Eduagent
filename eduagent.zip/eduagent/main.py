from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from planner_agent import create_study_plan
from tutor_agent import teach
from quiz_agent import generate_quiz
from evaluation_agent import evaluate

app = FastAPI(title="EduAgent API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5173", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def home():
    return {"message": "Welcome to EduAgent"}

@app.get("/study-plan/{goal}")
def study_plan(goal: str):
    return create_study_plan(goal)

@app.get("/teach/{topic}")
def tutor(topic: str):
    return {"lesson": teach(topic)}

@app.get("/quiz/{topic}")
def quiz(topic: str):
    return generate_quiz(topic)

@app.get("/evaluate/{score}")
def result(score: int):
    return {"result": evaluate(score)} 
