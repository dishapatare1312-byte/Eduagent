def evaluate(score):
    if score >= 70:
        return "Excellent! Move to the next topic."
    else:
        return "You need more practice. Revise this topic."