def teach(topic):
    return f"This is a simple explanation of {topic}. Study the basic concepts and practice examples."